//
//  swiftUI_clientApp.swift
//  swiftUI-client
//
//  Created by Sandy Ludosky on 04/11/2023.
//

import SwiftUI

@main
struct swiftUI_clientApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
