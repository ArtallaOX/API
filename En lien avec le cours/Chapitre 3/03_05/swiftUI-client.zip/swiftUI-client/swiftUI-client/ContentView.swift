//
//  ContentView.swift
//  swiftUI-client
//
//  Created by Sandy Ludosky on 04/11/2023.
//

import SwiftUI
import UIKit
import Foundation


func fetchCatImageData(with text: String, completion: @escaping (Data?) -> Void) {
    guard let url = URL(string: "https://cataas.com/cat/says/\(text)") else {
        completion(nil)
        return
    }

    URLSession.shared.dataTask(with: url) { data, response, error in
        completion(data)
    }.resume()
}


struct ContentView: View {
    @State private var userInput: String = ""
    @State private var cgImage: CGImage? = nil
    
    var body: some View {
        VStack(spacing: 20) {
            TextField("Enter text for endpoint", text: $userInput)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button("Fetch Image") {
                fetchCatImageData(with: userInput) { data in
                    if let uiImage = UIImage(data: data!) {
                        DispatchQueue.main.async {
                            self.cgImage = uiImage.cgImage
                            self.userInput = ""  // Clear the text input
                        }
                    }
                }
            }
            .padding(.horizontal)

            if let cgImage = cgImage {
                Image(cgImage, scale: UIScreen.main.scale, label: Text("Cat Image"))
                    .resizable()
                    .scaledToFit()
            } else {
                Text("Image will appear here")
            }
        }
        .padding()
    }
}






